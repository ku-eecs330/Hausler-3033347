import numpy as np

class Deque:
  def __init__(self, capacity=10):
    self.capacity = capacity
    # Initialize front and rear pointers.
    self.front = -1
    self.back = -1
    # Initialize size of the deque.
    self.size = 0
    # Use a zero intialized NumPy array to store elements.
    self.array = np.zeros(self.capacity, dtype=int)